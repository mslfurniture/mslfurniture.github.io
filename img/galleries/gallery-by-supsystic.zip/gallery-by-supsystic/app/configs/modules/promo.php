<?php return array(
    'promo_plugin_name'     => 'Gallery by Supsystic',
    'promo_plugin_url'      => 'http://supsystic.com/plugins/photo-gallery/',
    'promo_video_url'       => '',
    'promo_plugin_features' => array(
        '18 Overlay Effects',
        'Four Border Types',
        'Two Area Grid',
    ),
);
