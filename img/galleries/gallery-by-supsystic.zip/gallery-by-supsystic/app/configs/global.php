<?php

return array(
    'pro_url' => 'http://supsystic.com/plugins/photo-gallery/'
);