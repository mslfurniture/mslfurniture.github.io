<?php

/**
 * Class GridGallery_Galleries_Exception_RenameException
 *
 * @package GridGallery\Galleries\Exception
 */
class GridGallery_Galleries_Exception_RenameException extends RuntimeException
{

} 