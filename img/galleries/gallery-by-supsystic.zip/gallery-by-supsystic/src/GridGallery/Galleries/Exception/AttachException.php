<?php


class GridGallery_Galleries_Exception_AttachException extends RuntimeException
{

} 