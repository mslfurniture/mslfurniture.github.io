<?php

/**
 * Class GridGallery_Galleries_Exception_EmptyTitleException
 *
 * @package GridGallery\Galleries\Exception
 * @author Artur Kovalevsky
 */
class GridGallery_Galleries_Exception_EmptyTitleException extends RuntimeException
{

} 